# Apunts per a SMX

Aquesta pàgina agrupa els mòduls més habituals de SMX.

- {{ module_index("0221") }}
