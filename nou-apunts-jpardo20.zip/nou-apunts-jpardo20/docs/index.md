# Benvinguts als Apunts

Escull el teu itinerari 👇

- [Per a SMX](smx/index.md)
- [Per a DAM](dam/index.md)

També pots navegar pel menú superior o cercar directament.
